<?php
// ============================================================
//  TechCopy — Funzioni di utilità
// ============================================================

function h(mixed $v): string {
    return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8');
}

function json_response(mixed $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function redirect(string $url): void {
    header('Location: '.$url);
    exit;
}

function flash(string $msg, string $type = 'success'): void {
    session_init();
    $_SESSION['flash'] = ['msg' => $msg, 'type' => $type];
}

function get_flash(): ?array {
    session_init();
    $f = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $f;
}

function status_badge(string $s): string {
    return match($s) {
        'open'    => '<span class="badge badge-open">🟠 Aperto</span>',
        'pending' => '<span class="badge badge-pending">🟡 In attesa</span>',
        'closed'  => '<span class="badge badge-closed">🟢 Chiuso</span>',
        default   => '<span class="badge">'.h($s).'</span>',
    };
}

function priority_badge(string $p): string {
    return match($p) {
        'urgent' => '<span class="badge badge-urgent">🔴 Urgente</span>',
        'high'   => '<span class="badge badge-open">🔶 Alta</span>',
        default  => '<span class="badge badge-viewer">Normale</span>',
    };
}

function log_ticket(int $ticketId, int $userId, string $userName, string $action): void {
    $stmt = db()->prepare('INSERT INTO ticket_history (ticket_id,user_id,user_name,action) VALUES (?,?,?,?)');
    $stmt->execute([$ticketId, $userId, $userName, $action]);
}

function format_minutes(int $min): string {
    if ($min <= 0) return '—';
    $h = intdiv($min, 60);
    $m = $min % 60;
    return $h > 0 ? "{$h}h {$m}min" : "{$m}min";
}

function allowed_upload(string $mime): bool {
    return in_array($mime, [
        'image/jpeg','image/png','image/gif','application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'text/plain',
    ]);
}

/** Etichetta leggibile per il campo adf */
function adf_label(string $adf): string {
    return match($adf) {
        'simple' => 'ADF Fronte',
        'duplex' => 'ADF Fronte/Retro',
        default  => 'Nessun ADF',
    };
}
