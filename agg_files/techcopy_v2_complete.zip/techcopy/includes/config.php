<?php
// ============================================================
//  TechCopy — Configurazione
//  Modifica DB_HOST / DB_USER / DB_PASS se necessario
// ============================================================
define('DB_HOST',       'localhost');
define('DB_USER',       'root');
define('DB_PASS',       '');
define('DB_NAME',       'techcopy');
define('DB_CHARSET',    'utf8mb4');
define('APP_NAME',      'TechCopy');
define('UPLOAD_DIR',    __DIR__ . '/../uploads/');
define('UPLOAD_MAX_MB', 10);

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset='.DB_CHARSET;
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            die(json_encode(['error' => 'DB connection failed: '.$e->getMessage()]));
        }
    }
    return $pdo;
}
