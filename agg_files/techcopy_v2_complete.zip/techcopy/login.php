<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
if (current_user()) { header('Location: /techcopy/index.php'); exit; }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (login_user(trim($_POST['email']??''), $_POST['password']??'')) {
        header('Location: /techcopy/index.php'); exit;
    }
    $error = 'Email o password non validi.';
}

$roleIcon = ['admin'=>'👑','supervisor'=>'🔍','tech'=>'🔧','viewer'=>'👁'];
$roleLabel= ['admin'=>'Amministratore','supervisor'=>'Supervisore','tech'=>'Tecnico','viewer'=>'Visualizzatore'];
?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login — TechCopy</title>
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/techcopy/assets/css/style.css">
</head>
<body>
<div class="login-screen">
  <div class="login-box">
    <div class="login-logo">
      <div class="icon">🖨️</div>
      <div><h1>TechCopy</h1><span>Gestione Assistenza Stampanti</span></div>
    </div>

    <?php if ($error): ?>
    <div class="error-msg">⚠️ <?= h($error) ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="form-group">
        <label>Email</label>
        <input type="email" name="email" value="<?= h($_POST['email']??'') ?>" placeholder="email@azienda.it" required autofocus>
      </div>
      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" placeholder="••••••••" required>
      </div>
      <button type="submit" class="btn btn-primary btn-full" style="margin-top:8px">🔐 Accedi</button>
    </form>

    <div style="margin-top:28px;padding-top:20px;border-top:1px solid var(--border)">
      <p style="font-size:11px;color:var(--text3);margin-bottom:10px;font-family:var(--mono)">ACCOUNT DEMO — clicca per compilare</p>
      <?php
      try {
          $users = db()->query("SELECT name,email,role,avatar,color FROM users WHERE active=1 ORDER BY FIELD(role,'admin','supervisor','tech','viewer') LIMIT 5")->fetchAll();
          foreach ($users as $u):
      ?>
      <div class="user-pill" onclick="document.querySelector('[name=email]').value='<?= h($u['email']) ?>';document.querySelector('[name=password]').value='admin123'">
        <div style="width:30px;height:30px;border-radius:50%;background:<?= h($u['color']) ?>22;color:<?= h($u['color']) ?>;border:1.5px solid <?= h($u['color']) ?>;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:600;flex-shrink:0"><?= h($u['avatar']) ?></div>
        <div style="flex:1;font-size:13px"><?= h($u['name']) ?></div>
        <span class="badge badge-<?= h($u['role']) ?>"><?= ($roleIcon[$u['role']]??'•').' '.($roleLabel[$u['role']]??$u['role']) ?></span>
      </div>
      <?php endforeach; } catch(Exception $e) {} ?>
    </div>
  </div>
</div>
</body>
</html>
