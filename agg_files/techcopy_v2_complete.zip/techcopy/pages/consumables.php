<?php
require_once __DIR__ . '/../includes/layout.php';
require_login();
$db = db();

if ($_SERVER['REQUEST_METHOD']==='POST' && can_manage_consumables()) {
    $action = $_POST['action']??'';
    if ($action==='create') {
        $db->prepare("INSERT INTO consumables (name,code,brand,type,color,stock,min_stock,unit,price,supplier,notes) VALUES (?,?,?,?,?,?,?,?,?,?,?)")
           ->execute([$_POST['name'],$_POST['code'],$_POST['brand'],$_POST['type'],$_POST['color'],(int)$_POST['stock'],(int)$_POST['min_stock'],$_POST['unit'],$_POST['price']?:null,$_POST['supplier'],$_POST['notes']]);
        flash('Consumabile aggiunto ✅'); redirect('/techcopy/pages/consumables.php');
    }
    if ($action==='adjust') {
        $id=(int)$_POST['id']; $delta=(int)$_POST['delta'];
        $db->prepare("UPDATE consumables SET stock=GREATEST(0,stock+?) WHERE id=?")->execute([$delta,$id]);
        $type=$delta>0?'carico':'scarico';
        $db->prepare("INSERT INTO stock_movements (consumable_id,user_id,type,quantity) VALUES (?,?,?,?)")->execute([$id,current_user()['id'],$type,abs($delta)]);
        flash('Stock aggiornato'); redirect('/techcopy/pages/consumables.php');
    }
}

$filter=$_GET['filter']??'all'; $search=$_GET['q']??'';
$where='1=1'; $params=[];
if ($filter==='low') { $where.=" AND stock<=min_stock"; }
if ($filter==='out') { $where.=" AND stock=0"; }
if ($search) { $where.=" AND (name LIKE ? OR code LIKE ? OR brand LIKE ?)"; $params=array_fill(0,3,"%$search%"); }
$stmt=$db->prepare("SELECT * FROM consumables WHERE $where ORDER BY CASE WHEN stock=0 THEN 0 WHEN stock<=min_stock THEN 1 ELSE 2 END, name");
$stmt->execute($params); $consumables=$stmt->fetchAll();
$lowCount = $db->query("SELECT COUNT(*) FROM consumables WHERE stock<=min_stock")->fetchColumn();
$outCount = $db->query("SELECT COUNT(*) FROM consumables WHERE stock=0")->fetchColumn();

layout_header('Consumabili','consumables');
?>
<?php if($lowCount>0): ?>
<div class="alert alert-warning">⚠️ <?= $lowCount ?> articoli sotto la soglia minima — <?= $outCount ?> esauriti.</div>
<?php endif; ?>

<div class="filter-bar">
  <form method="GET" style="display:contents">
    <a href="?filter=all" class="btn btn-sm <?= $filter==='all'?'btn-primary':'btn-secondary' ?>">Tutti</a>
    <a href="?filter=low" class="btn btn-sm <?= $filter==='low'?'btn-primary':'btn-secondary' ?>">⚠️ Stock basso (<?= $lowCount ?>)</a>
    <a href="?filter=out" class="btn btn-sm <?= $filter==='out'?'btn-primary':'btn-secondary' ?>">🔴 Esauriti (<?= $outCount ?>)</a>
    <div style="margin-left:auto;display:flex;gap:8px">
      <div class="search-bar"><span>🔍</span><input name="q" value="<?= h($search) ?>" placeholder="Cerca..." oninput="this.form.submit()"><input type="hidden" name="filter" value="<?= h($filter) ?>"></div>
      <?php if(can_manage_consumables()): ?><a href="/techcopy/pages/consumable_form.php" class="btn btn-primary btn-sm">➕ Nuovo</a><?php endif; ?>
    </div>
  </form>
</div>

<div class="table-wrap">
  <table>
    <thead><tr><th>Prodotto</th><th>Codice</th><th>Tipo</th><th>Marca</th><th>Stock</th><th>Min.</th><th>Livello</th><?php if(can_manage_consumables()):?><th>Azioni</th><?php endif;?></tr></thead>
    <tbody>
      <?php foreach($consumables as $c):
        $pct   = $c['min_stock']>0 ? min(100,($c['stock']/($c['min_stock']*2))*100) : 50;
        $color = $c['stock']==0 ? 'var(--red)' : ($c['stock']<=$c['min_stock'] ? 'var(--orange)' : 'var(--green)');
      ?>
      <tr>
        <td><strong><?= h($c['name']) ?></strong></td>
        <td style="font-family:var(--mono);font-size:12px"><?= h($c['code']) ?></td>
        <td><span class="chip"><?= h($c['type']) ?></span></td>
        <td><?= h($c['brand']) ?></td>
        <td id="stock-<?= $c['id'] ?>" style="font-family:var(--mono);font-weight:600;color:<?= $color ?>"><?= $c['stock'] ?> <?= h($c['unit']) ?></td>
        <td style="font-family:var(--mono);font-size:12px;color:var(--text2)"><?= $c['min_stock'] ?></td>
        <td style="min-width:90px"><div class="stock-bar"><div class="stock-fill" id="fill-<?= $c['id'] ?>" style="width:<?= $pct ?>%;background:<?= $color ?>"></div></div></td>
        <?php if(can_manage_consumables()): ?>
        <td>
          <div class="td-actions">
            <form method="POST" style="display:contents"><input type="hidden" name="action" value="adjust"><input type="hidden" name="id" value="<?= $c['id'] ?>"><input type="hidden" name="delta" value="1"><button type="submit" class="btn btn-success btn-sm">+1</button></form>
            <form method="POST" style="display:contents"><input type="hidden" name="action" value="adjust"><input type="hidden" name="id" value="<?= $c['id'] ?>"><input type="hidden" name="delta" value="-1"><button type="submit" class="btn btn-danger btn-sm" <?= $c['stock']==0?'disabled':'' ?>>-1</button></form>
          </div>
        </td>
        <?php endif; ?>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php layout_footer(); ?>
