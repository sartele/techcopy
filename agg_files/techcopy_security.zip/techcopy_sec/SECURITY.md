# TechCopy — Guida alla Sicurezza

## Come applicare gli aggiornamenti

Sostituisci questi 6 file nel progetto:

| File | Cartella | Cosa cambia |
|------|----------|-------------|
| `config.php`   | `includes/` | Debug off, costanti sicurezza |
| `auth.php`     | `includes/` | CSRF, rate limiting, session fix |
| `helpers.php`  | `includes/` | CSRF field, upload sicuro |
| `layout.php`   | `includes/` | Header HTTP sicurezza |
| `login.php`    | radice      | Rate limiting, demo nascosto |
| `.htaccess`    | radice      | Blocchi Apache |
| `.htaccess`    | `uploads/`  | Blocca PHP in uploads (**nuovo file**) |

---

## Cosa è stato corretto

### 1. 🔐 Protezione CSRF (Cross-Site Request Forgery)
**Problema:** qualsiasi sito esterno poteva inviare form POST a TechCopy usando la sessione dell'utente loggato.

**Soluzione:** ogni form ora deve includere `<?= csrf_field() ?>` e ogni handler POST chiama `csrf_verify()` prima di qualsiasi azione.

**Come aggiornare i form esistenti:**
Aprire ogni file `.php` in `pages/` e:
1. Aggiungere `<?= csrf_field() ?>` dentro ogni `<form method="POST">`
2. Aggiungere `csrf_verify();` come prima riga di ogni blocco `if ($_SERVER['REQUEST_METHOD'] === 'POST')`

Esempio:
```php
// In ogni pagina PHP con form POST, PRIMA di qualsiasi azione:
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();   // ← AGGIUNGERE QUESTA RIGA
    $action = $_POST['action'] ?? '';
    // ...
}
```

```html
<!-- In ogni form HTML -->
<form method="POST">
  <?= csrf_field() ?>   <!-- ← AGGIUNGERE QUESTA RIGA -->
  ...
</form>
```

---

### 2. 🔒 Rate limiting login (Anti Brute-Force)
**Problema:** un attaccante poteva tentare migliaia di password senza limiti.

**Soluzione:** dopo 5 tentativi falliti dallo stesso IP, il login viene bloccato per 15 minuti. I valori sono configurabili in `config.php`:
```php
define('LOGIN_MAX_ATTEMPTS', 5);      // tentativi prima del blocco
define('LOGIN_LOCKOUT_SECONDS', 900); // secondi di blocco (15 min)
```

---

### 3. 🔄 Session Fixation Fix
**Problema:** un attaccante poteva iniettare un session ID noto prima del login.

**Soluzione:** `session_regenerate_id(true)` viene chiamato ad ogni login con successo, garantendo che la sessione post-login abbia sempre un ID nuovo e non prevedibile.

---

### 4. ⏱️ Timeout sessione inattività
**Problema:** una sessione aperta restava valida indefinitamente.

**Soluzione:** dopo 8 ore di inattività la sessione scade automaticamente. Configurabile:
```php
define('SESSION_LIFETIME', 28800); // secondi (8 ore)
```

---

### 5. 🛡️ Header HTTP di sicurezza
**Problema:** mancavano gli header che istruiscono il browser a comportarsi in modo sicuro.

**Soluzione:** ogni pagina invia automaticamente:
- `X-Frame-Options: DENY` — blocca clickjacking (iframe)
- `X-Content-Type-Options: nosniff` — blocca MIME sniffing
- `Content-Security-Policy` — specifica da dove possono arrivare script, stili, immagini
- `Referrer-Policy` — limita le informazioni inviate ai siti terzi
- `Cache-Control: no-store` — le pagine autenticate non vengono cachate dal browser

---

### 6. 🚫 Upload file sicuro
**Problema:** il tipo MIME era verificato con `mime_content_type()` ma il nome file originale era mantenuto parzialmente.

**Soluzione:**
- Nome file completamente randomico (`tc_ID_RANDOMHEX.ext`) — impossibile indovinare l'URL
- Estensione verificata da whitelist esplicita
- MIME verificato con `finfo` (più affidabile)
- Il file `.htaccess` in `uploads/` blocca qualsiasi esecuzione PHP anche se il controllo venisse aggirato

---

### 7. 🔇 Soppressione errori PHP
**Problema:** un errore di produzione poteva rivelare percorsi del server, nomi di variabili, struttura del codice.

**Soluzione:** in `config.php` impostare `APP_DEBUG = false` (già predisposto). Gli errori vengono loggati sul server ma non mostrati all'utente.

---

### 8. 🙈 Account demo nascosti in produzione
**Problema:** la pagina di login mostrava sempre gli account demo con le password.

**Soluzione:** la sezione demo appare solo se `APP_DEBUG = true`. In produzione è invisibile.

---

## Checklist per il passaggio in produzione

Prima di spostare su un server esterno:

- [ ] Impostare `APP_DEBUG = false` in `config.php`
- [ ] Cambiare le password di tutti gli utenti demo
- [ ] Eliminare `setup.php` (o decommentare il blocco in `.htaccess`)
- [ ] Configurare HTTPS sul server (Let's Encrypt è gratuito)
- [ ] Decommentare `Strict-Transport-Security` in `.htaccess` dopo aver attivato HTTPS
- [ ] Aggiungere `<?= csrf_field() ?>` e `csrf_verify()` in tutte le pagine con form POST
- [ ] Verificare che la cartella `uploads/` abbia il suo `.htaccess`
- [ ] Impostare i permessi corretti: `uploads/` scrivibile dal web server, `includes/` non accessibile dal web
- [ ] Configurare backup automatico del database
- [ ] Impostare un percorso reale per `error_log` in `config.php`
- [ ] Verificare che MySQL accetti connessioni solo da localhost (se DB locale al server)

---

## Cosa NON è stato modificato (by design)

**PDO con prepared statements** — già correttamente implementato in tutto il progetto. Non c'è rischio di SQL injection perché tutti i valori dinamici passano tramite `?` e `->execute([...])`.

**Output escaping con `h()`** — già applicato consistentemente su tutti i dati stampati a video. Non c'è rischio di XSS riflesso nei template.

**Controllo ruoli** — già implementato con funzioni dedicate (`can_manage_clients()`, `can_edit_ticket()`, ecc.) applicate su ogni azione.
