-- ============================================================
--  TechCopy — Migrazione: collegamento consumabili ↔ ticket
--  Eseguire in phpMyAdmin su database "techcopy" già esistente
--  oppure: mysql -u root techcopy < migration_consumabili.sql
-- ============================================================

USE techcopy;

-- Aggiunge la colonna consumable_id a ticket_parts
-- (se non esiste già — sicuro da eseguire più volte)
ALTER TABLE ticket_parts
  ADD COLUMN IF NOT EXISTS consumable_id INT DEFAULT NULL
    AFTER ticket_id,
  ADD COLUMN IF NOT EXISTS quantity INT NOT NULL DEFAULT 1
    AFTER part_code;

-- Aggiunge il vincolo FK solo se non esiste
SET @fk_exists = (
  SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
  WHERE CONSTRAINT_SCHEMA = 'techcopy'
    AND TABLE_NAME = 'ticket_parts'
    AND CONSTRAINT_NAME = 'fk_tp_consumable'
    AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);
SET @sql = IF(@fk_exists = 0,
  'ALTER TABLE ticket_parts ADD CONSTRAINT fk_tp_consumable FOREIGN KEY (consumable_id) REFERENCES consumables(id) ON DELETE SET NULL',
  'SELECT ''FK already exists'' AS info'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SELECT 'Migrazione completata ✅' AS risultato;
